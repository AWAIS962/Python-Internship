"""
Task 3: pandas – DataFrames
- Create a DataFrame
- Select columns/rows
- Add a computed column
- Save to CSV
"""
import pandas as pd

data = {
    "A": [1, 2, 3, 4],
    "B": [10, 20, 30, 40],
}

df = pd.DataFrame(data)
df["A_plus_B"] = df["A"] + df["B"]

print("DataFrame:")
print(df)

# Basic selection examples
print("\nFirst two rows:")
print(df.head(2))

print("\nOnly column B:")
print(df["B"])

# Save
df.to_csv("task3_output.csv", index=False)
print("\nSaved CSV -> task3_output.csv")
