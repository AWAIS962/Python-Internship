"""
Task 6: matplotlib – Bar & Line
- Create a bar chart for category totals
- Overlay a line plot for cumulative totals
- Save PNG files
"""
import matplotlib.pyplot as plt
import numpy as np

categories = ["A","B","C","D"]
values = [5, 3, 9, 2]

# Bar chart
plt.figure()
plt.bar(categories, values)
plt.title("Category Totals (Bar)")
plt.xlabel("Category")
plt.ylabel("Total")
plt.tight_layout()
plt.savefig("task6_bar.png")
print("Saved -> task6_bar.png")

# Line chart of cumulative totals
cum = np.cumsum(values)
plt.figure()
plt.plot(categories, cum, marker="o")
plt.title("Cumulative Totals (Line)")
plt.xlabel("Category")
plt.ylabel("Cumulative")
plt.grid(True)
plt.tight_layout()
plt.savefig("task6_line.png")
print("Saved -> task6_line.png")
