"""
Task 5: matplotlib – Plot Basics (Line)
- Create a simple line plot
- Label axes and title
- Save as PNG (no style/colors enforced)
"""
import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [2, 3, 5, 7, 11]

plt.figure()
plt.plot(x, y, marker="o")
plt.title("Simple Line Plot")
plt.xlabel("X")
plt.ylabel("Y")
plt.grid(True)
plt.tight_layout()
plt.savefig("task5_line.png")
print("Saved plot -> task5_line.png")
