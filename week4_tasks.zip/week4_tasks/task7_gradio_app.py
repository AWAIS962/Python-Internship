"""
Task 7: Gradio – Simple UI
- Build a tiny app with a greeting function and text transforms
- To run: `python task7_gradio_app.py` then open the link in the console
"""
import gradio as gr

def greet(name: str) -> str:
    return f"Hello {name.strip() or 'there'}"

def transform(text: str) -> tuple[str, str]:
    t = text or ""
    return t.upper(), t.lower()

with gr.Blocks() as demo:
    gr.Markdown("# Week 4 · Simple Gradio App")
    with gr.Row():
        name = gr.Textbox(label="Your name")
        out = gr.Textbox(label="Greeting")
    btn = gr.Button("Greet")
    btn.click(fn=greet, inputs=name, outputs=out)

    gr.Markdown("### Text Transform")
    inp = gr.Textbox(label="Input text")
    upper = gr.Textbox(label="UPPER")
    lower = gr.Textbox(label="lower")
    gr.Button("Transform").click(fn=transform, inputs=inp, outputs=[upper, lower])

if __name__ == "__main__":
    demo.launch()
