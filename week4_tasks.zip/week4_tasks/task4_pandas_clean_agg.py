"""
Task 4: pandas – Cleaning & Aggregation
- Build messy dataset with missing values and duplicates
- Clean (drop duplicates, fill or drop NaNs)
- Group by Region and compute aggregations
- Save cleaned data and summary
"""
import pandas as pd
import numpy as np

raw = pd.DataFrame({
    "Region": ["East","West","East","North","West","East", None],
    "Sales": [10, 20, None, 15, 20, 30, 5],
    "Rep":   ["Ali","Sara","Ali","Umar","Sara","Ali","Zed"]
})

print("Raw data:")
print(raw)

# Drop rows with missing Region
clean = raw.dropna(subset=["Region"]).copy()

# Fill missing Sales with 0
clean["Sales"] = clean["Sales"].fillna(0)

# Remove duplicate rows
clean = clean.drop_duplicates()

print("\nCleaned data:")
print(clean)

# Aggregation
summary = clean.groupby("Region", as_index=False).agg(
    total_sales=("Sales","sum"),
    avg_sales=("Sales","mean"),
    orders=("Sales","count"),
    unique_reps=("Rep","nunique")
)

print("\nSummary by Region:")
print(summary)

clean.to_csv("task4_cleaned.csv", index=False)
summary.to_csv("task4_summary.csv", index=False)
print("\nSaved -> task4_cleaned.csv, task4_summary.csv")
