"""
Task 2: requests – JSON & Errors
- Call a public API that returns JSON
- Parse JSON safely
- Demonstrate error handling for non-200 responses
"""
import requests

def get_user(username: str = "octocat"):
    url = f"https://api.github.com/users/{username}"
    try:
        r = requests.get(url, timeout=10)
        r.raise_for_status()  # raise HTTPError for 4xx/5xx
        data = r.json()
        print("Login:", data.get("login"))
        print("Name:", data.get("name"))
        print("Public Repos:", data.get("public_repos"))
        print("Followers:", data.get("followers"))
    except requests.exceptions.HTTPError as e:
        print(f"HTTP error: {e} (status={getattr(e.response,'status_code',None)})")
        # If JSON error body exists, show message:
        try:
            print("Error body:", r.json())
        except Exception:
            pass
    except requests.exceptions.RequestException as e:
        print("Request failed:", e)

if __name__ == "__main__":
    get_user("octocat")
    # Example of an error (user that doesn't exist):
    get_user("this_user_definitely_should_not_exist_123456")
