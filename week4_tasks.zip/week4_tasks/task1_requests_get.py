"""
Task 1: requests – GET
- Fetch two URLs and print status codes
- Handle common exceptions (timeouts, connection errors)
- Optional: print round-trip time
"""
import requests, time

URLS = [
    "https://api.github.com",
    "https://httpbin.org/status/200"
]

def fetch_status(url: str, timeout: float = 10.0) -> None:
    start = time.perf_counter()
    try:
        r = requests.get(url, timeout=timeout)
        elapsed = (time.perf_counter() - start) * 1000
        print(f"{url} -> {r.status_code} ({elapsed:.1f} ms)")
    except requests.exceptions.Timeout:
        print(f"{url} -> ERROR: request timed out")
    except requests.exceptions.ConnectionError as e:
        print(f"{url} -> ERROR: connection error: {e}")
    except requests.exceptions.RequestException as e:
        print(f"{url} -> ERROR: {e}")

if __name__ == "__main__":
    for u in URLS:
        fetch_status(u)
