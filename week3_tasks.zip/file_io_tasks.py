# Task 1: Merge 2 files into merged.txt
file1 = "file1.txt"
file2 = "file2.txt"
merged_file = "merged.txt"

# Create sample files for testing
with open(file1, "w") as f:
    f.write("Hello from file 1.\nThis is the first file.\n")
with open(file2, "w") as f:
    f.write("Hello from file 2.\nThis is the second file.\n")

# Merge files
with open(merged_file, "w") as mf:
    for filename in [file1, file2]:
        with open(filename, "r") as f:
            mf.write(f.read())

print(f"Merged {file1} and {file2} into {merged_file}")

# Task 2: Count lines, words, and characters
with open(merged_file, "r") as f:
    content = f.read()

line_count = len(content.splitlines())
word_count = len(content.split())
char_count = len(content)

print(f"Lines: {line_count}")
print(f"Words: {word_count}")
print(f"Characters: {char_count}")
