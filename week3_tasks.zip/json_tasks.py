import json
import csv

# Task 1: Save student records to JSON and reload
students = [
    {"id": 1, "name": "Awais", "marks": 85},
    {"id": 2, "name": "Ahmed", "marks": 92}
]

with open("students.json", "w") as f:
    json.dump(students, f)

with open("students.json", "r") as f:
    data = json.load(f)
    print("Student Records:", data)

# Task 2: CSV to JSON converter
csv_filename = "students.csv"
with open(csv_filename, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["id", "name", "marks"])
    writer.writeheader()
    writer.writerows(students)

json_filename = "students_from_csv.json"
with open(csv_filename, "r") as csv_file:
    reader = csv.DictReader(csv_file)
    csv_data = list(reader)

with open(json_filename, "w") as json_file:
    json.dump(csv_data, json_file)

print(f"CSV file '{csv_filename}' converted to JSON '{json_filename}'")
