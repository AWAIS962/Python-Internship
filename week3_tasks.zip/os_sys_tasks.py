import os
import sys

# Task 1: List .py files and their sizes
print("Python files and sizes:")
for file in os.listdir("."):
    if file.endswith(".py"):
        size = os.path.getsize(file)
        print(f"{file} - {size} bytes")

# Task 2: Read filename from argv and print contents
if len(sys.argv) > 1:
    filename = sys.argv[1]
    if os.path.exists(filename):
        with open(filename, "r") as f:
            print(f"\nContents of {filename}:\n")
            print(f.read())
    else:
        print(f"File '{filename}' not found.")
else:
    print("\nUsage: python os_sys_tasks.py <filename>")
